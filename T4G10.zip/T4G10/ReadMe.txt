### FEUP 1st year 2nd semester - Prog
2nd project - 'Agência de Viagens “NiceHolidays”'

All the required funcionalities for the project have been implemented.
We chose to use a struct for the agency (although, the dates, addresses, travel packs and clients are classes).
We would like to have implemented more sets and/or maps in place of some of the vectors.
We added more funcionalities to the project:
    -The user can choose to also see the unavailable travel packs printed;
    -Many checks for the user input to guarantee it was given/written in the correct way;
    -Extensive use of exceptions to make the program flow better and be more user-friendly;
	-User can choose how many destinations are on "Top N" shown

Developed by (T4G10):
                Joao de Jesus Costa - up201806560 (FEUP)
                Joao Lucas Silva Martins - up201806436 (FEUP)
